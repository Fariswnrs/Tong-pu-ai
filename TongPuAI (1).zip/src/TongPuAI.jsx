
import React, { useState } from "react";

export default function TongPuAI() {
  const [chat, setChat] = useState("");
  const [messages, setMessages] = useState([
    { from: "ai", text: "Halo! Sa Tong Pu AI. Ko tanya apa, kita cerita..." },
  ]);

  const handleSend = () => {
    if (!chat.trim()) return;

    const newMessages = [...messages, { from: "user", text: chat }];
    setMessages(newMessages);
    setChat("");

    setTimeout(() => {
      const response = \`Ehh ko tanya: "\${chat}"? Hmm... sa rasa begini e...\`;
      setMessages((prev) => [...prev, { from: "ai", text: response }]);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-yellow-50 p-4 flex flex-col items-center justify-center">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
        <h1 className="text-2xl font-bold text-center text-brown-800 mb-4">
          Tong Pu AI
        </h1>
        <div className="space-y-2 max-h-96 overflow-y-auto mb-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={\`p-2 rounded-xl text-sm max-w-[80%] \${msg.from === "user" ? "ml-auto bg-blue-200" : "mr-auto bg-gray-200"}\`}
            >
              {msg.text}
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            value={chat}
            onChange={(e) => setChat(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Tulis di sini e..."
            className="flex-1 p-2 border border-gray-300 rounded-xl"
          />
          <button
            onClick={handleSend}
            className="bg-brown-700 text-white px-4 py-2 rounded-xl"
          >
            Kirim
          </button>
        </div>
      </div>
    </div>
  );
}
