
import React from "react";
import ReactDOM from "react-dom/client";
import TongPuAI from "./TongPuAI";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <TongPuAI />
  </React.StrictMode>
);
